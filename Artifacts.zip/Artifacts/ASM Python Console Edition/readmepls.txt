Hey thanks for giving the program a try, most of the features that are to be implemented in the mobile app / web based versions have been added as 
best as I can in python. 


================================================================================================================================================================


Example users for standard and admin accounts:

Admin:  Username = Admin
	Password = Admin

Standard: Username = User
	  Password = User


================================================================================================================================================================


Program loading options: 

> Run the AustralianSportsManager.py file in IDLE.
(Most stable release, would prefer you try this but for convenience there is the exe version...)

or

> Navigate to dist/AustralianSportsManager.exe and give that a try. 
(There are some bugs with this, entering blank lines or options that cannot be picked will cause the program to get stuck, this is very much a demo.)

Edit: I've had to removed the executable version as windows defender does not like it, likely because it was made with pyinstaller.


================================================================================================================================================================

- Jye Thomson